# Ebook Translator (A Calibre plugin)

## Manual
- [English](English.md)


## A Brief Tour
- ▶️ [How to Translate Ebook into a Specified Language by Ebook Translator (A Calibre Plugin)](https://www.youtube.com/watch?v=mNEL0UEMOeU)

## Community Tutorial
- ▶️ [Translate Ebooks in SECONDS! This Automatic Translator is a GAME CHANGER!](https://www.youtube.com/watch?v=kV_j-Up85Ww)
- ▶️ [Como traduzir ebooks Kindle 2024](https://www.youtube.com/watch?v=ragP7kbPGRc)
- ▶️ [Aprenda a Traduzir Ebooks com Plugin do Calibre | Mantendo Layout Original](https://www.youtube.com/watch?v=tQWIOA75Tnw)
- ▶️ [Traducir libros desde cualquier idioma con Calibre, fácil!!!!](https://www.youtube.com/watch?v=K2SRzjSc3Xk)
- [Przetłumacz sobie e-booka! Wtyczka Ebook Translator do Calibre używa ChatGPT, DeepL lub Google i radzi sobie bardzo dobrze](https://swiatczytnikow.pl/przetlumacz-sobie-e-booka-wtyczka-ebook-translator-do-calibre-uzywa-chatgpt-deepl-lub-google-i-radzi-sobie-bardzo-dobrze/)
- [Tradução automatizada de arquivos pelo Calibre](https://ciceroog.medium.com/tradu%C3%A7%C3%A3o-automatizada-de-arquivos-pelo-calibre-71210b234be)
