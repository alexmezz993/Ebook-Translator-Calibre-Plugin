anthropic = {
    'Hebrew (with Niqqud)': 'Ensure that all text in Hebrew is with Niqqud, '
    'a system of diacritical signs used to represent vowels or distinguish '
    'between alternative pronunciations of letters.',
}
